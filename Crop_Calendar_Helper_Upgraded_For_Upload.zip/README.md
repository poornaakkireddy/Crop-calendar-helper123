# Crop Calendar Helper

A small Python 3.10+ project for planning crop tasks by month. It uses only the Python standard library and stores data in SQLite.

## Features

- Add, browse, search, complete, and delete crop tasks
- View a month-by-month calendar and summaries with overdue warnings
- Import CSV and export CSV, plain text, and Markdown reports
- Read-only browser view at `http://localhost:8000`
- Input validation, diagnostic logs, atomic SQLite transactions, and stale-edit conflict detection
- Automatic one-time import of older `crop_tasks.json` data into SQLite

## Run

```console
python crop_calendar_helper.py
```

To open the browser view in another terminal:

```console
python web_view.py
```

Then visit `http://localhost:8000`. The browser view is read-only and listens on the local computer only.

## Tests

Run the regression suite with Python's built-in test runner:

```console
python -m unittest discover -v
```

The tests cover validation boundaries, summaries, SQLite persistence, legacy migration, and concurrent edit behavior. No third-party packages are needed.

## Project files

- `crop_calendar_helper.py` - terminal app, validation, SQLite persistence, CSV import, and exports
- `web_view.py` - read-only local browser view
- `test_crop_calendar_helper.py` - automated regression tests
- `sample_tasks.json` / `sample_tasks.csv` - sample data; the CSV includes invalid rows for import demonstrations
- `pyproject.toml` - project metadata and Python version

Runtime data and logs are created beside the scripts: `crop_tasks.db`, `crop_calendar.log`, and (when needed) `import_errors.log`. Exported reports go in `exports/`.

## Quick demo

1. Start the app and choose **10** to load sample data.
2. Choose **3** to view the calendar or **7** for the summary and warnings.
3. Choose **8** to export reports.
4. Start `web_view.py` and open `http://localhost:8000` to see the same saved data.
