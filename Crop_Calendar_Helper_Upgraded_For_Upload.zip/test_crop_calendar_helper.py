"""Automated regression tests for crop calendar validation and persistence."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import crop_calendar_helper as app


class ValidationTests(unittest.TestCase):
    def test_month_boundaries_and_names(self):
        self.assertEqual(app.parse_month("1"), 1)
        self.assertEqual(app.parse_month("Dec"), 12)
        self.assertIsNone(app.parse_month("0"))
        self.assertIsNone(app.parse_month("13"))

    def test_validate_fields_normalizes_and_rejects_invalid_data(self):
        clean, error = app.validate_fields("  tomato ", "sowing", "Mar", "pending", "  early bed ")
        self.assertEqual(error, "")
        self.assertEqual(clean, {"crop": "Tomato", "task_type": "Sowing", "month": 3,
                                 "status": "Pending", "notes": "early bed"})
        clean, error = app.validate_fields("", "Sowing", 3, "Pending", "")
        self.assertIsNone(clean)
        self.assertTrue(error)

    def test_month_parser_rejects_ambiguous_and_out_of_range_values(self):
        for value in ("", "0", "13", "J", "Smarch", "-1"):
            with self.subTest(value=value):
                self.assertIsNone(app.parse_month(value))

    def test_validation_enforces_lengths_characters_and_enums(self):
        valid = app.validate_fields("A" * (app.MAX_CROP + 1), "Sowing", 1, "Pending", "")
        self.assertIsNone(valid[0])
        for fields in (
            ("Tomato!", "Sowing", 1, "Pending", ""),
            ("Tomato", "Unknown", 1, "Pending", ""),
            ("Tomato", "Sowing", 1, "Unknown", ""),
            ("Tomato", "Sowing", 1, "Pending", "x" * (app.MAX_NOTES + 1)),
        ):
            with self.subTest(fields=fields):
                clean, error = app.validate_fields(*fields)
                self.assertIsNone(clean)
                self.assertTrue(error)


class SummaryTests(unittest.TestCase):
    def test_empty_summary_is_safe(self):
        summary = app.compute_summary([])
        self.assertEqual(summary["total"], 0)
        self.assertEqual(summary["completion_pct"], 0.0)
        self.assertEqual(summary["busiest"], None)
        self.assertEqual(summary["avg_per_active_month"], 0.0)

    def test_summary_counts_tasks_and_active_months(self):
        tasks = [
            app.Task(1, "Bean", "Sowing", 3, "Done"),
            app.Task(2, "Bean", "Care", 3, "Pending"),
            app.Task(3, "Rice", "Harvest", 9, "Pending"),
        ]
        summary = app.compute_summary(tasks)
        self.assertEqual(summary["total"], 3)
        self.assertEqual(summary["done"], 1)
        self.assertEqual(summary["pending"], 2)
        self.assertEqual(summary["crops"], 2)
        self.assertEqual(summary["avg_per_active_month"], 1.5)
        self.assertEqual(summary["busiest"], (3, 2))


class PersistenceTests(unittest.TestCase):
    def test_sqlite_round_trip_and_idempotent_save(self):
        with tempfile.TemporaryDirectory() as folder:
            db = str(Path(folder) / "tasks.db")
            with patch.object(app, "DATA_FILE", db), patch.object(app, "LEGACY_DATA_FILE", str(Path(folder) / "old.json")), patch.object(app, "_last_snapshot", None):
                original = [app.Task(1, "Tomato", "Sowing", 3, "Pending", "seed")]
                app.save_tasks(original)
                self.assertEqual(app.load_tasks(), original)
                app.save_tasks(original)
                self.assertEqual(app.load_tasks(), original)

    def test_migrates_legacy_json_once(self):
        with tempfile.TemporaryDirectory() as folder:
            db = str(Path(folder) / "tasks.db")
            legacy = Path(folder) / "crop_tasks.json"
            legacy.write_text('[{"id": 7, "crop": "Bean", "task_type": "Care", "month": 5}]', encoding="utf-8")
            with patch.object(app, "DATA_FILE", db), patch.object(app, "LEGACY_DATA_FILE", str(legacy)), patch.object(app, "_last_snapshot", None):
                self.assertEqual(app.load_tasks(), [app.Task(7, "Bean", "Care", 5, "Pending", "")])
                self.assertEqual(app.load_tasks(), [app.Task(7, "Bean", "Care", 5, "Pending", "")])

    def test_rejects_stale_concurrent_edit(self):
        with tempfile.TemporaryDirectory() as folder:
            db = str(Path(folder) / "tasks.db")
            legacy = str(Path(folder) / "old.json")
            with patch.object(app, "DATA_FILE", db), patch.object(app, "LEGACY_DATA_FILE", legacy), patch.object(app, "_last_snapshot", None):
                app.save_tasks([app.Task(1, "Bean", "Care", 5)])
                stale = app.load_tasks()
                app.load_tasks()  # Simulates a second session loading the same task.
                app._last_snapshot = {1: app.Task(1, "Bean", "Care", 5)}
                app.save_tasks([app.Task(1, "Bean", "Care", 5, "Done")])
                app._last_snapshot = {1: stale[0]}
                with self.assertRaisesRegex(RuntimeError, "changed in another session"):
                    app.save_tasks([app.Task(1, "Bean", "Care", 5, "Pending", "stale edit")])

    def test_merges_non_conflicting_concurrent_additions(self):
        with tempfile.TemporaryDirectory() as folder:
            db = str(Path(folder) / "tasks.db")
            with patch.object(app, "DATA_FILE", db), patch.object(
                app, "LEGACY_DATA_FILE", str(Path(folder) / "old.json")
            ), patch.object(app, "_last_snapshot", None):
                app.save_tasks([])
                app.load_tasks()  # First session snapshot.
                second_session = app.load_tasks()  # Simulate the other session.
                app._last_snapshot = {}
                app.save_tasks([app.Task(1, "Bean", "Care", 5)])
                app._last_snapshot = {}
                second_session.append(app.Task(2, "Rice", "Sowing", 6))
                app.save_tasks(second_session)
                self.assertEqual(
                    app.load_tasks(),
                    [app.Task(1, "Bean", "Care", 5), app.Task(2, "Rice", "Sowing", 6)],
                )


if __name__ == "__main__":
    unittest.main()
