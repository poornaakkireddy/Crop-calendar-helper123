"""Show Crop Calendar Helper data in a web browser. Run: python web_view.py
Then open http://localhost:8000  (keep crop_calendar_helper.py in the same folder)."""
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer

from crop_calendar_helper import MONTHS, compute_summary, is_overdue, load_tasks

CSS = """body{font-family:system-ui,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem}
table{border-collapse:collapse;width:100%;margin-bottom:2rem}
th,td{border:1px solid #ccc;padding:6px 10px;text-align:left}
th{background:#2e7d32;color:#fff}.Done{color:#2e7d32}.Pending{color:#b26a00}.Overdue{color:#c62828;font-weight:bold}"""


def page() -> str:
    tasks = load_tasks()
    s = compute_summary(tasks)
    rows = ""
    for t in sorted(tasks, key=lambda t: (t.month, t.crop)):
        st = "Overdue" if is_overdue(t) else t.status
        rows += (f"<tr><td>{MONTHS[t.month-1]}</td><td>{escape(t.crop)}</td>"
                 f"<td>{escape(t.task_type)}</td><td class='{st}'>{st}</td>"
                 f"<td>{escape(t.notes)}</td></tr>")
    stats = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in [
        ("Total tasks", s["total"]), ("Distinct crops", s["crops"]),
        ("Done / Pending", f"{s['done']} / {s['pending']} ({s['completion_pct']}%)"),
        ("Overdue", s["overdue"]), ("Avg per active month", s["avg_per_active_month"])])
    return (f"<!doctype html><meta charset='utf-8'><title>Crop Calendar</title><style>{CSS}</style>"
            f"<h1>Crop Calendar Helper</h1><h2>Summary</h2><table>{stats}</table>"
            f"<h2>Calendar</h2><table><tr><th>Month</th><th>Crop</th><th>Task</th>"
            f"<th>Status</th><th>Notes</th></tr>{rows}</table>")


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = page().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    print("Open http://localhost:8000  (Ctrl+C to stop)")
    HTTPServer(("localhost", 8000), Handler).serve_forever()
